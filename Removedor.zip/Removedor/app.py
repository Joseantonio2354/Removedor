import os

os.system("python webUI.py")